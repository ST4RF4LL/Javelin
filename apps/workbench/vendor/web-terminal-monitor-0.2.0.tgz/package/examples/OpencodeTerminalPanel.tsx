import type { CSSProperties } from 'react';
import { TerminalEmbed } from 'web-terminal-monitor';

export interface OpencodeTerminalMetadata {
  socket_name?: string;
  target?: string;
  live?: boolean;
}

export interface OpencodeTerminalPanelProps {
  terminal?: OpencodeTerminalMetadata | null;
  sidecarUrl?: string;
  title?: string;
  height?: CSSProperties['height'];
  /** Monitoring embeds are read-only by default; set false to allow interaction. */
  readOnly?: boolean;
}

/** Application adapter: install web-terminal-monitor, then map the audit metadata. */
export function OpencodeTerminalPanel({
  terminal,
  sidecarUrl = 'http://127.0.0.1:4182/',
  title = '实时终端',
  height = 560,
  readOnly = true,
}: OpencodeTerminalPanelProps) {
  const socket = terminal?.socket_name?.trim();
  if (!socket || terminal?.live === false) {
    return (
      <section aria-label={title} style={emptyStyle}>
        <strong>{title}</strong>
        <p style={{ marginBottom: 0 }}>
          {terminal?.live === false
            ? '此任务当前没有运行中的终端，可在原工作台查看已归档日志。'
            : '此任务尚未提供终端连接信息。'}
        </p>
      </section>
    );
  }

  return (
    <TerminalEmbed
      serverUrl={sidecarUrl}
      socket={socket}
      target={terminal?.target || 'audit:tui'}
      readOnly={readOnly}
      title={title}
      height={height}
    />
  );
}

const emptyStyle: CSSProperties = {
  padding: 24, border: '1px solid #dbe0e8', borderRadius: 12, color: '#526078', fontSize: 14, lineHeight: 1.7,
};

export default OpencodeTerminalPanel;
