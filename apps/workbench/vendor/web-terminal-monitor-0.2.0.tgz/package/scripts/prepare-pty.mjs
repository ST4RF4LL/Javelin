import { chmod, stat } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';

// node-pty 1.1 macOS prebuild archives can lose the spawn-helper executable bit.
// Limit the repair to this dependency's two known helper locations.
if (process.platform === 'darwin') {
  const require = createRequire(import.meta.url);
  const directory = path.dirname(require.resolve('node-pty/package.json'));
  for (const relative of [`prebuilds/darwin-${process.arch}/spawn-helper`, 'build/Release/spawn-helper']) {
    const filename = path.join(directory, relative);
    try {
      const info = await stat(filename);
      if (info.isFile() && !(info.mode & 0o100)) await chmod(filename, info.mode | 0o111);
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
  }
}
