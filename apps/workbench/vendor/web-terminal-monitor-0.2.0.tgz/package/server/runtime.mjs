import crypto from 'node:crypto';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import * as nodePty from 'node-pty';
import headless from '@xterm/headless';
import serializer from '@xterm/addon-serialize';
import { createTmuxProvider } from './tmux.mjs';

const { Terminal } = headless;
const { SerializeAddon } = serializer;
export const VERSION = '1.0.0';
export const MAX_SESSIONS = 8;
const MAX_QUEUE = 1024 * 1024;

export function dimensions(cols = 100, rows = 30) {
  return {
    cols: Math.min(240, Math.max(20, Number.isFinite(Number(cols)) ? Math.floor(Number(cols)) : 100)),
    rows: Math.min(100, Math.max(10, Number.isFinite(Number(rows)) ? Math.floor(Number(rows)) : 30)),
  };
}

function publicSession(session) {
  const { id, name, kind, status, command, cwd, cols, rows, createdAt, exitCode, profile } = session;
  return { id, name, kind, status, command, cwd, cols, rows, createdAt, exitCode, profile, clients: session.viewers.size };
}

function trackMouseEncoding(terminal) {
  // SerializeAddon restores tracking (1000/1002/1003), but omits its encoding.
  // Parser hooks observe complete sequences even when PTY chunks split them.
  let encoding = 0;
  const handlers = [
    terminal.parser.registerCsiHandler({ prefix: '?', final: 'h' }, (params) => {
      for (const param of params) if (param === 1006 || param === 1016) encoding = param;
      return false;
    }),
    terminal.parser.registerCsiHandler({ prefix: '?', final: 'l' }, (params) => {
      // xterm uses one active encoding: resetting either mode resets both.
      if (params.includes(1006) || params.includes(1016)) encoding = 0;
      return false;
    }),
    terminal.parser.registerEscHandler({ final: 'c' }, () => {
      encoding = 0;
      return false;
    }),
  ];
  // Unlike RIS, xterm's DECSTR (CSI ! p) preserves the mouse encoding.
  // Unsupported 1005/1015 modes also leave it unchanged.
  return {
    // Snapshots replay into a reset browser terminal, whose encoding is DEFAULT.
    serialize: () => encoding ? `\x1b[?${encoding}h` : '',
    dispose: () => handlers.forEach((handler) => handler.dispose()),
  };
}

export function createRuntime(options = {}) {
  const spawnPty = options.spawnPty || nodePty.spawn;
  const tmux = options.tmux || createTmuxProvider();
  const managed = new Map();
  const externalAttachments = new Set();
  const allowInput = options.allowInput ?? process.env.TERMINAL_ALLOW_INPUT !== '0';
  const allowShell = options.allowShell ?? process.env.TERMINAL_ALLOW_SHELL !== '0';
  const cwd = options.cwd || process.env.TERMINAL_CWD || process.cwd();
  const shell = options.shell || process.env.TERMINAL_SHELL || process.env.SHELL || (os.platform() === 'win32' ? 'powershell.exe' : '/bin/zsh');
  const token = crypto.randomBytes(32).toString('hex');
  const maxSessions = options.maxSessions || MAX_SESSIONS;
  const platformUrl = options.platformUrl || process.env.PLATFORM_URL || 'http://127.0.0.1:4181/audits';
  let closed = false;

  const profiles = [{ id: 'demo', label: 'TUI 演示', description: '运行实时全屏终端演示，验证颜色、光标及重连' }];
  if (allowShell) profiles.push({ id: 'shell', label: '本地 Shell', description: '在配置的工作目录启动交互式终端' });

  function enqueue(session, operation) {
    const next = session.pending.then(operation);
    // Keep the queue usable even when a disconnected viewer throws.
    session.pending = next.catch((error) => options.onError?.(error));
    return next;
  }

  function createSession(input) {
    if (closed) throw Object.assign(new Error('终端服务正在关闭'), { status: 503 });
    if (!input || !profiles.some((profile) => profile.id === input.profile)) throw Object.assign(new Error('请选择允许的终端类型'), { status: 400 });
    if (managed.size >= maxSessions) throw Object.assign(new Error(`最多保留 ${maxSessions} 个终端，请先关闭不需要的会话`), { status: 409 });
    const { cols, rows } = dimensions(input.cols, input.rows);
    const isDemo = input.profile === 'demo';
    const executable = isDemo ? process.execPath : shell;
    const args = isDemo ? [fileURLToPath(new URL('./demo.mjs', import.meta.url))] : [];
    const terminal = new Terminal({ cols, rows, scrollback: 1500, allowProposedApi: true });
    const serialize = new SerializeAddon();
    terminal.loadAddon(serialize);
    const mouseEncoding = trackMouseEncoding(terminal);
    // Never forward the server capability token into subprocess environment.
    let pty;
    try {
      pty = spawnPty(executable, args, { name: 'xterm-256color', cols, rows, cwd, env: { ...process.env, TERM: 'xterm-256color', COLORTERM: 'truecolor' } });
    } catch (error) {
      mouseEncoding.dispose();
      terminal.dispose();
      throw Object.assign(new Error(`无法启动终端：${error.message}`), { status: 500 });
    }
    const session = {
      id: `managed:${crypto.randomUUID()}`, name: isDemo ? 'TUI 演示' : '本地 Shell', profile: input.profile,
      kind: 'managed', status: 'running', command: isDemo ? 'TUI demo' : executable,
      cwd, cols, rows, createdAt: new Date().toISOString(), terminal, serialize, mouseEncoding, pty,
      viewers: new Set(), pending: Promise.resolve(), queuedChars: 0, paused: false, disposed: false,
    };
    managed.set(session.id, session);
    session.dataListener = pty.onData((data) => {
      if (session.disposed) return;
      session.queuedChars += data.length;
      if (session.queuedChars >= MAX_QUEUE && !session.paused) {
        session.paused = true;
        pty.pause?.();
      }
      enqueue(session, () => new Promise((resolve) => {
        terminal.write(data, () => {
          session.queuedChars -= data.length;
          for (const viewer of session.viewers) viewer.output(data);
          if (session.paused && session.queuedChars < MAX_QUEUE / 2) {
            session.paused = false;
            pty.resume?.();
          }
          resolve();
        });
      }));
    });
    session.exitListener = pty.onExit(({ exitCode }) => {
      if (session.disposed) return;
      session.status = 'exited';
      session.exitCode = exitCode;
      enqueue(session, () => {
        for (const viewer of session.viewers) viewer.exit(exitCode);
      });
    });
    return publicSession(session);
  }

  async function listSessions() {
    const external = await tmux.listSessions();
    return { sessions: [...external.sessions, ...[...managed.values()].map(publicSession)], warnings: external.warnings };
  }

  async function getSession(id) {
    if (managed.has(id)) return publicSession(managed.get(id));
    if (id.startsWith('tmux:')) return tmux.resolve(id);
    return undefined;
  }

  async function removeSession(id) {
    if (id.startsWith('tmux:')) throw Object.assign(new Error('外部 tmux 会话仅可断开预览，请在原平台管理任务'), { status: 403 });
    const session = managed.get(id);
    if (!session) throw Object.assign(new Error('终端会话不存在'), { status: 404 });
    managed.delete(id);
    session.disposed = true;
    try { session.pty.kill(); } catch { /* A process may have exited before its exit event arrives. */ }
    await session.pending;
    session.dataListener?.dispose();
    session.exitListener?.dispose();
    for (const viewer of session.viewers) viewer.close();
    session.viewers.clear();
    session.mouseEncoding.dispose();
    session.terminal.dispose();
  }

  async function attach(id, viewer, requestedInput = false) {
    const session = managed.get(id);
    if (session) {
      const writable = allowInput && requestedInput && session.profile === 'shell';
      const attachment = {
        input(data) { if (writable && session.status === 'running' && !session.disposed) session.pty.write(data); },
        resize(cols, rows) {
          if (session.status !== 'running' || session.disposed) return;
          const size = dimensions(cols, rows);
          enqueue(session, () => {
            if (session.disposed) return;
            session.cols = size.cols;
            session.rows = size.rows;
            session.terminal.resize(size.cols, size.rows);
            session.pty.resize(size.cols, size.rows);
            for (const client of session.viewers) client.size?.(size);
          });
        },
        detach() { session.viewers.delete(viewer); },
      };
      // A snapshot and listener installation share the data queue: no gap, replay, or reorder.
      await enqueue(session, () => {
        if (viewer.isClosed()) return;
        if (session.disposed) throw Object.assign(new Error('终端会话已关闭'), { status: 404 });
        viewer.ready(publicSession(session), !writable);
        viewer.output(session.serialize.serialize() + session.mouseEncoding.serialize());
        session.viewers.add(viewer);
        if (session.status === 'exited') viewer.exit(session.exitCode);
      });
      return attachment;
    }
    const external = await tmux.resolve(id);
    if (!external) throw Object.assign(new Error('终端会话不存在或已退出'), { status: 404 });
    if (viewer.isClosed()) return null;
    const writable = allowInput && requestedInput;
    const pty = tmux.attach(external, spawnPty, writable);
    viewer.ready(external, !writable);
    let detached = false;
    let sizeTimer;
    const dataListener = pty.onData((data) => viewer.output(data));
    const exitListener = pty.onExit(({ exitCode }) => { clearInterval(sizeTimer); if (!detached) viewer.exit(exitCode); });
    let checkingSize = false;
    sizeTimer = setInterval(async () => {
      if (detached || checkingSize || !tmux.getSize) return;
      checkingSize = true;
      try {
        const size = await tmux.getSize(external);
        if (!detached && size && (size.cols !== external.cols || size.rows !== external.rows)) {
          external.cols = size.cols;
          external.rows = size.rows;
          pty.resize(size.cols, size.rows);
          viewer.size?.({ ...size, fixed: true });
        }
      } catch { /* A disappearing tmux server is reported by its attach client. */ }
      finally { checkingSize = false; }
    }, 2000);
    sizeTimer.unref();
    const attachment = {
      input(data) { if (writable && !detached) pty.write(data); },
      resize() { viewer.size?.({ cols: external.cols, rows: external.rows, fixed: true }); },
      detach() {
        if (detached) return;
        detached = true;
        externalAttachments.delete(attachment);
        clearInterval(sizeTimer);
        dataListener.dispose();
        exitListener.dispose();
        // This kills the temporary attach client only. It never sends kill-session/server.
        try { pty.kill(); } catch { /* The tmux attach process may already have exited. */ }
      },
    };
    externalAttachments.add(attachment);
    return attachment;
  }

  async function close() {
    closed = true;
    for (const attachment of externalAttachments) attachment.detach();
    await Promise.allSettled([...managed.keys()].map(removeSession));
  }

  return {
    token, allowInput, createSession, listSessions, getSession, removeSession, attach, close,
    config: () => ({ platformUrl, allowInput, profiles, version: VERSION, token }),
  };
}
