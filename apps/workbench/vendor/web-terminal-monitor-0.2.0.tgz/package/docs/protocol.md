# 终端服务协议

本协议供同一台计算机上的 Web 前端接入。生产构建由 4182 同时提供页面和 API；开发页面 5182 将 `/api` 请求代理到 4182。

## HTTP

| 方法与路径 | 用途 |
| --- | --- |
| `GET /api/config` | 配置、固定启动项与当前进程的访问令牌 |
| `GET /api/sessions` | 发现的 tmux 会话与本服务创建的会话 |
| `GET /api/sessions/:id` | 查询单个会话，返回 `{ session }` |
| `POST /api/sessions` | 创建固定 `demo` 或 `shell` 启动项 |
| `DELETE /api/sessions/:id` | 结束并移除本服务创建的会话 |

`POST` 和 `DELETE` 请求必须带 `X-Terminal-Token: <token>`。`POST` 还需要 `Content-Type: application/json`。令牌来自配置接口，服务重新启动后会改变；不能用它作为持久用户身份。

配置响应：

```ts
interface TerminalConfig {
  platformUrl: string;
  allowInput: boolean;
  profiles: { id: 'demo' | 'shell'; label: string; description: string }[];
  version: string;
  token: string;
}
```

创建请求示例：

```json
{ "profile": "demo", "cols": 120, "rows": 32 }
```

尺寸限制为 20–240 列、10–100 行，后端会取整并限制范围。不接收客户端提交的命令、程序路径、工作目录或环境变量。

会话列表返回 `{ sessions: TerminalSession[], warnings: string[] }`。创建接口以 HTTP 201 返回 `{ session: TerminalSession }`；删除成功返回 `{ ok: true }`。错误响应为 `{ error: string }`，并使用对应的 HTTP 错误状态。

```ts
interface TerminalSession {
  id: string;
  name: string;
  kind: 'tmux' | 'managed';
  status: 'running' | 'exited';
  command?: string;
  cwd?: string;
  cols: number;
  rows: number;
  createdAt?: string;
  clients?: number;
  exitCode?: number;
  profile?: 'demo' | 'shell';
  tmuxSocket?: string;
  sessionName?: string;
  sessionId?: string;
}
```

`managed:<uuid>` 表示本服务管理的会话；`tmux:<socket>:<session_id>` 表示发现的外部会话，其中 tmux 的 `session_id` 类似 `$0`。始终使用列表返回的完整 ID，并将它传给 `encodeURIComponent`。删除接口拒绝结束外部 tmux 会话；监控退出不等于任务取消。

## WebSocket

连接时提供两个子协议，服务选择 `terminal-v1`，第二个值用于令牌验证：

```ts
const config = await fetch('/api/config').then((response) => response.json());
const url = new URL(`/api/terminal/${encodeURIComponent(session.id)}`, location.href);
url.protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
const socket = new WebSocket(url, ['terminal-v1', config.token]);
```

WebSocket 默认只读。显式追加 `input=1` 才请求交互；后端仍受 `TERMINAL_ALLOW_INPUT` 限制。演示会话始终只读。连接的实际权限由 `ready.readOnly` 给出，前端应遵守该值。随服务提供的 Web 页面为普通终端默认请求交互，`readonly=1` 可让页面以只读模式连接。

所有消息为 JSON 文本，不是二进制帧。终端 `output.data` 保留 ANSI / VT 控制序列，交给 xterm.js 的 `write` 方法，不应渲染为 HTML。

客户端到服务端：

```ts
type ClientMessage =
  | { type: 'resize'; cols: number; rows: number }
  | { type: 'input'; data: string; encoding?: 'utf8' | 'binary' }
  | { type: 'ack'; chars: number };
```

`input.data` 包含终端输入，包括需要发送的控制字符；只有获准交互的连接会被写入 PTY。省略 `encoding` 或使用 `'utf8'` 时，后端保留字符串并交由 PTY 按 UTF-8 写入。`'binary'` 用于 xterm.js `onBinary` 产生的旧式鼠标事件：`data` 的每个 UTF-16 码元必须不大于 255，后端将其按 Latin-1 转为原始字节再写入 PTY，防止高位坐标字节被 UTF-8 重编码。它仍然封装在 JSON 文本消息中，不是 WebSocket 二进制帧；其他 encoding 或包含超范围码元的 binary 输入会被拒绝。

`resize` 调整本服务创建的终端。外部 tmux 会话保留原有尺寸，不因浏览器尺寸变化而重排后台任务。

`ack.chars` 是已完成终端解析的字符串长度，使用 JavaScript `data.length`，**不是 UTF-8 字节数**。须在 xterm.js `write` 回调中确认，不能仅收到 WebSocket 消息就确认：

```ts
terminal.write(message.data, () => {
  if (socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({ type: 'ack', chars: message.data.length }));
  }
});
```

服务端到客户端：

```ts
type ServerMessage =
  | { type: 'ready'; session: TerminalSession; readOnly: boolean }
  | { type: 'output'; data: string }
  | { type: 'resize'; cols: number; rows: number; fixed?: boolean }
  | { type: 'exit'; exitCode: number }
  | { type: 'error'; message: string };
```

收到 `ready` 后重置浏览器终端，随后按顺序写入 `output`。本服务管理的会话先发送当前画面的序列化快照，再续接实时数据；tmux 通过新建的 attach 客户端重绘当前画面。不要把重连快照继续追加到旧终端状态。

流量控制以每条连接的消费确认为依据。未及时消费的连接可能被关闭；客户端应显示断开状态，并使用退避延迟重新连接。后端重启后先重新获取配置令牌，管理会话不会跨后端重启保留，外部 tmux 任务仍由原运行方管理。

默认最多保留 8 个管理会话、16 个 WebSocket 连接。HTTP 请求体和单个 WebSocket 消息限 16 KiB，单条输入字符串限 8192 个 JavaScript 字符。输出按 16 Ki 字符分块，未确认窗口为 64 Ki 字符，积压超过 2 Mi 字符会关闭连接；客户端必须确认快照数据和后续实时数据。

## iframe 参数

| 参数 | 用途 |
| --- | --- |
| `embed=1` | 使用嵌入布局 |
| `readonly=1` / `readonly=0` | 以只读 / 交互模式打开，优先于该会话在当前标签页保存的模式；服务端仍决定最终权限 |
| `session=<完整会话 ID>` | 按 API 返回的会话 ID 选择 |
| `socket=<socket 名>` | 按发现的 tmux socket 选择 |
| `target=audit:tui` | 用冒号前的会话名匹配，例如 `audit` |

目标必须已被服务发现。参数不会执行命令，不会创建任务，也不会切换底层 tmux 的活动窗口。使用 [React 示例](../examples/OpencodeTerminalPanel.tsx) 可自动编码这些参数；该监控示例 `readOnly` 默认 `true`，设为 `false` 则请求交互。

## 前端输入约定

键盘、粘贴和鼠标输入均须等待 `ready.readOnly === false`，并在断线、重连等待、只读切换或退出时停止发送。鼠标事件由 xterm.js 根据后台程序发出的鼠标协议自动编码，不能把 DOM 的像素坐标直接传给 PTY。当前鼠标模式可通过 `terminal.modes.mouseTrackingMode` 读取。

`terminal.onData` 的输入使用默认 / `'utf8'` 编码；`terminal.onBinary` 的输入必须使用 `'binary'`。前端将输入按最多 2048 个 UTF-16 码元分块，UTF-8 输入不会在合法代理对中间切分，以同时满足 JSON 消息大小限制和 Unicode 完整性。每批最多发送 4 帧；有积压时按 16 ms 间隔继续发送。WebSocket 的 `bufferedAmount` 达到 64 KiB 时暂停取出新帧，等待缓冲降低。

前端待发送队列最多累计 1,048,576 个 UTF-16 码元，超限会拒绝此次新增内容并提示分批粘贴。队列绑定当前 WebSocket；断线、重连、切换会话、改为只读或进程退出时清空，避免将旧连接中尚未发送的输入带到下一条连接。这些限制管理的是客户端排队输入；服务端的单消息和单字符串限制仍然适用。

粘贴使用 xterm.js 的 `paste` 方法，以遵守后台程序启用的 bracketed-paste 模式；不自行追加回车。系统剪贴板访问被拒绝时提供手动粘贴框，用户明确点击发送后写入。IME 使用 xterm.js 原生 composition 路径，避免自制逐键转发破坏候选词输入。
