#!/usr/bin/env node
// A local, deterministic ANSI application for verifying full-screen terminal rendering.
const stages = ['读取任务配置', '并行扫描仓库', '分析访问控制', '汇总证据', '生成审计报告'];
let ticks = 0;
const startedAt = Date.now();
const write = (value) => process.stdout.write(value);
const fit = (value, width) => value.padEnd(width).slice(0, width);

function draw() {
  const cols = Math.max(20, process.stdout.columns || 100);
  const rows = Math.max(10, process.stdout.rows || 30);
  const inner = Math.min(cols - 8, 86);
  const progress = ticks % 101;
  const barWidth = Math.max(12, inner - 16);
  const filled = Math.floor((progress / 100) * barWidth);
  const stage = Math.min(4, Math.floor(progress / 21));
  const elapsed = Math.floor((Date.now() - startedAt) / 1000);
  const compact = cols < 75;
  const shortWidth = Math.max(6, Math.min(cols - 11, 45));
  const shortFilled = Math.floor(progress * shortWidth / 100);
  const lines = compact ? [
    '\x1b[1;38;5;81m OPENCODE / LIVE\x1b[0m',
    '\x1b[38;5;244m 真实 PTY · 演示\x1b[0m',
    '',
    ` \x1b[32m${['⠋', '⠙', '⠹', '⠸'][ticks % 4]} RUNNING\x1b[0m  ${elapsed}s`,
    '',
    ` \x1b[38;5;81m${'━'.repeat(shortFilled)}\x1b[38;5;238m${'━'.repeat(shortWidth - shortFilled)}\x1b[0m ${String(progress).padStart(3)}%`,
    '',
    ` \x1b[32mrepo    RUNNING\x1b[0m`,
    ` \x1b[36mpolicy  ANALYZING\x1b[0m`,
    ` \x1b[33mreview  WAITING\x1b[0m`,
    '',
    ` ${cols} × ${rows} / UTF-8`,
    '\x1b[38;5;244m 演示，非真实任务\x1b[0m',
  ] : [
    '\x1b[1;38;5;81m  OPENCODE / LIVE TERMINAL\x1b[0m',
    '\x1b[38;5;244m  真实 PTY · ANSI 颜色 · 光标更新 · Alternate Screen\x1b[0m',
    '',
    `  \x1b[38;5;120m${['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'][ticks % 10]}\x1b[0m ${stages[stage]}   \x1b[38;5;244m${elapsed}s\x1b[0m`,
    '',
    `  \x1b[38;5;81m${'━'.repeat(filled)}\x1b[38;5;238m${'━'.repeat(barWidth - filled)}\x1b[0m  ${String(progress).padStart(3)}%`,
    '',
    '  AGENT               STATE           FILES     FINDINGS',
    `  ${fit('repository-analyst', 20)}\x1b[32mRUNNING\x1b[0m         ${String(ticks * 3).padStart(4)}          2`,
    `  ${fit('policy-auditor', 20)}\x1b[36mANALYZING\x1b[0m       ${String(ticks * 2).padStart(4)}          5`,
    `  ${fit('evidence-reviewer', 20)}\x1b[33mWAITING\x1b[0m         ${String(ticks).padStart(4)}          0`,
    '',
    '\x1b[38;5;244m  演示数据；此窗口没有连接到实际审计任务。\x1b[0m',
    `\x1b[38;5;244m  终端尺寸 ${cols} × ${rows}  /  断开浏览器后仍持续运行\x1b[0m`,
  ];
  write('\x1b[H' + lines.slice(0, rows - 1).map((line) => line + '\x1b[K').join('\r\n') + '\x1b[J');
  ticks += 1;
}

write('\x1b[?1049h\x1b[?25l\x1b[2J');
draw();
const interval = setInterval(draw, 250);
process.stdout.on('resize', draw);
function finish() {
  clearInterval(interval);
  write('\x1b[?25h\x1b[?1049l');
  process.exit(0);
}
process.on('SIGTERM', finish);
process.on('SIGINT', finish);
