# 作为组件或服务导入

包提供四个独立入口：React 原生终端 `WebTerminal`、完整页面嵌入组件 `TerminalEmbed`、无框架的客户端 `createTerminalClient` / URL 构建器 `buildTerminalEmbedUrl`，以及 Node 后端 `web-terminal-monitor/server`。当前版本通过本地目录或安装包使用，尚未发布到 npm registry。

## 安装

先在本项目生成构建产物：

```sh
npm install
npm run build
```

在接入项目中安装本地目录：

```sh
npm install /Users/wh4lter/Workspace/web-terminal-monitor
```

也可在本项目运行 `npm pack`，把生成的 `web-terminal-monitor-0.2.0.tgz` 交给其他项目安装。已生成的交付包位于 `artifacts/web-terminal-monitor-0.2.0.tgz`：

```sh
npm install /absolute/path/web-terminal-monitor-0.2.0.tgz
```

React 组件由宿主项目提供 React。Node 后端需要 Node.js 22.12+；连接 tmux 还需要宿主机安装 tmux，并使用运行任务的系统用户。终端服务必须运行在能访问任务 PTY / tmux 的机器上。

如果 npm 提示安装脚本被白名单拦截，使用后端前需在接入项目中允许 `node-pty` 和本包的安装脚本。使用支持该命令的 npm 时可执行：

```sh
npm install-scripts approve node-pty
npm install-scripts approve web-terminal-monitor
npm rebuild node-pty web-terminal-monitor
```

本包的安装脚本修复 macOS 下 `node-pty` 辅助程序可能缺失的执行权限；只使用前端组件时不会启动 PTY。

## 完整页面嵌入

对于 `opencode_multi_agents` 或其他语言实现的工作台，优先使用独立终端服务，再嵌入它的页面。终端的连接状态、输入模式、粘贴入口和工具栏都由该页面负责。

```tsx
import { TerminalEmbed } from 'web-terminal-monitor';

export function TaskTerminal() {
  return (
    <TerminalEmbed
      serverUrl="http://127.0.0.1:4183/"
      socket="owa-web-terminal-demo"
      target="opencode-demo:tui"
      height={620}
      readOnly={false}
    />
  );
}
```

`TerminalEmbed` 不需要导入本包的 CSS，可在服务端渲染时使用。组件只生成 iframe 和外层标题；后台进程由终端服务管理。卸载组件或关闭页面只断开连接，不终止 tmux 中的任务。

| 属性 | 含义 |
| --- | --- |
| `serverUrl` | 必填，完整 HTTP(S) 服务根目录地址，不允许内嵌用户名或密码，不支持指定自定义 HTML 文件 |
| `sessionId` | `/api/sessions` 返回的会话 ID；提供时优先于 `socket` / `target` |
| `socket` | 服务已发现的 tmux socket 名；未提供 `sessionId` 时必填 |
| `target` | 如 `audit:tui`，会话名部分用于定位会话 |
| `readOnly` | 默认 `false`；为 `true` 时初始只读，服务端仍有最终输入权限 |
| `title` | 默认“实时终端” |
| `height` | iframe 高度，默认 `560`，不包含外层标题高度 |
| `className` / `style` | 作用于外层容器 |
| `onLoad` | iframe 文档加载事件；不代表终端已经连通 |

`target` **不会切换 tmux 的活动窗口**。页面显示所选会话当前的活动窗口；socket、target 和 sessionId 也不能用于提交启动命令。非法地址或缺少连接信息时，组件显示明确的空态提示。

原平台可直接使用 [OpencodeTerminalPanel 适配示例](../examples/OpencodeTerminalPanel.tsx)，将 `audit.terminal.socket_name` / `target` / `live` 映射到组件。这个面向审计监控的适配层保留 `readOnly=true` 的默认值，需要操作时传入 `readOnly={false}`。

## 原生 React 终端

需要把终端画面放进自己的工具栏和布局时，使用 `WebTerminal`。它负责获取配置、解析会话和建立连接，直接展示终端画面；宿主可以通过事件显示状态，通过 ref 实现按钮。

```tsx
import { useRef } from 'react';
import { WebTerminal, type TerminalHandle } from 'web-terminal-monitor';
import 'web-terminal-monitor/styles.css';

export function TaskTerminal() {
  const terminal = useRef<TerminalHandle>(null);
  return (
    <section>
      <button onClick={() => terminal.current?.focus()}>聚焦终端</button>
      <button onClick={() => terminal.current?.sendKey('\u001b')}>Esc</button>
      <WebTerminal
        ref={terminal}
        serverUrl="http://127.0.0.1:4183/"
        socket="owa-web-terminal-demo"
        target="opencode-demo:tui"
        readOnly={false}
        height={620}
        onError={(message) => { if (message) console.error(message); }}
      />
    </section>
  );
}
```

原生组件需要导入 `web-terminal-monitor/styles.css`。`serverUrl` 可省略，默认同源根路径；显式传入服务地址时，可包含路径前缀。会话选择、`readOnly` 和 `height` 的含义与嵌入组件相同，另外支持：

| 属性或 ref 方法 | 含义 |
| --- | --- |
| `fontSize` | 终端字体大小 |
| `connected` | 默认 `true`；设为 `false` 断开客户端连接 |
| `reconnectKey` | 改变此值会重新连接，默认 `0` |
| `onStatus(status)` | 连接状态变化 |
| `onError(message)` | 错误信息；空字符串表示错误已清除 |
| `onDimensions(cols, rows)` | 当前终端字符列数和行数 |
| `onInputMode({ readOnly, mouseMode })` | 后端确认的输入权限和当前 TUI 鼠标模式 |
| `ref.focus()` | 聚焦终端 |
| `ref.getSelection()` | 读取选中文本 |
| `ref.exportText()` | 导出当前终端缓冲区文本 |
| `ref.paste(text)` | 通过终端粘贴协议发送文本，不额外追加回车 |
| `ref.sendKey(data)` | 发送终端按键序列，如 Esc 为 `\u001b` |

原生组件没有 iframe 工具栏。复制、粘贴、鼠标和键盘行为沿用终端实现；需要自定义粘贴按钮时，可由宿主读取剪贴板后调用 `ref.paste(text)`。只读或未连接时，输入会被拒绝。

**跨 origin 直连需要后端显式允许前端 origin。** 例如 4181 前端直接连接 4183 终端服务，需要在后端配置 `allowedOrigins: ['http://127.0.0.1:4181']`，或启动独立服务时设置 `TERMINAL_ALLOWED_ORIGINS`。iframe 内的 API 请求来自终端服务自身，不需要为了 iframe 配置跨 origin API 权限；iframe 的宿主来源由 `frameOrigins` / `PLATFORM_URL` 控制。

## 非 React 前端

通过 URL 构建器生成 iframe 地址，可用于 Vue、Svelte、模板页面或其他前端：

```ts
import { buildTerminalEmbedUrl } from 'web-terminal-monitor/embed-url';

const src = buildTerminalEmbedUrl({
  serverUrl: 'http://127.0.0.1:4183/',
  socket: 'owa-web-terminal-demo',
  target: 'opencode-demo:tui',
  readOnly: false,
});
// 将 src 赋给 iframe.src。
```

自行创建 iframe 时，为剪贴板和全屏入口设置 `allow="clipboard-read; clipboard-write; fullscreen"`，为画面设置合适的高度，并提供可访问的 `title`。构建器使用 `URLSearchParams` 编码参数，清理旧的连接参数，保留服务路径前缀及无关 query 参数。服务路径会补齐结尾的 `/`，让页面资源和 API 使用同一个服务根目录；例如 `/terminal` 归一化为 `/terminal/`，不要传入自定义的 `terminal.html` 文件。地址无效或缺少会话选择时抛出 `TypeError`。

不使用 React 的项目也可直接导入 `web-terminal-monitor/embed-url` 与 `web-terminal-monitor/client` 子入口，避免加载组件模块；它们分别导出 `buildTerminalEmbedUrl` 和 `createTerminalClient`。

也可通过客户端读取会话元数据：

```ts
import { createTerminalClient } from 'web-terminal-monitor/client';

const client = createTerminalClient({ serverUrl: 'http://127.0.0.1:4183/' });
const { sessions, warnings } = await client.getSessions();
const config = await client.getConfig();

// 仅在用户需要新建 Shell 时调用；不会影响已有 tmux 任务。
const shell = await client.createSession('shell', config.token, { cols: 120, rows: 32 });
// Shell 不再使用时，调用 await client.deleteSession(shell.id, config.token)。
```

客户端还提供 `getSession(id)`、`apiUrl(path)` 和 `terminalUrl(id, { readOnly })`。查询方法支持 `{ signal }` 取消请求，创建方法的第三个参数也支持 `signal`，删除方法的第三个参数支持 `{ signal }`；`createTerminalClient` 可接收自定义 `fetch`。WebSocket 令牌通过子协议传递，手工使用 WebSocket 时请遵循 [通信协议](protocol.md)，不要把令牌写进 URL。

## 在 Node 服务中导入后端

导入后端入口不会自动监听端口，也不会自动创建终端会话：

```js
import { createTerminalServer } from 'web-terminal-monitor/server';

const terminal = createTerminalServer({
  allowedOrigins: ['http://127.0.0.1:4181'],
  frameOrigins: ['http://127.0.0.1:4181'],
});

terminal.server.listen(4183, '127.0.0.1');
// 主服务退出时执行 await terminal.close()，释放终端客户端和托管进程。
```

它返回自己的 HTTP server、runtime 和 `close()` 方法，便于由宿主控制启动、关闭及监听错误。后端服务默认按现有本机访问边界校验 Host、Origin、令牌和会话，不能将上述示例视为公网多用户认证方案。停止后端会结束它创建的 Shell / 演示进程；外部 tmux 会话继续运行。

包内包含独立终端页面的构建产物，因此该服务也能承载 `TerminalEmbed` 使用的页面。若设置 `serverUrl="https://example.test/terminal/"`，前端和 URL 构建器会保留 `/terminal/` 前缀；后端路由仍位于根 `/api`，反向代理必须剥离前缀，并同时转发页面资源、HTTP API 和 WebSocket upgrade。

浏览器中的 `127.0.0.1` 指浏览器所在计算机。当前使用方式适用于同机访问，不会自动部署到其他机器，也未修改 `opencode_multi_agents` 项目。
