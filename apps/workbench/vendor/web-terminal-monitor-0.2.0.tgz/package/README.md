# Web Terminal Monitor

运行在本机的通用 Web 终端，可作为 `opencode_multi_agents` 审计详情中的交互终端或监控窗口。浏览器使用 xterm.js，后端用 node-pty 连接真正的伪终端，通过 WebSocket 传递原始终端控制序列，支持颜色、光标移动、清屏、全屏 TUI、键盘输入和 TUI 鼠标操作。

可作为独立服务运行，也可通过 `web-terminal-monitor` 包导入 React 组件、前端客户端和 Node 后端。当前实现没有修改 `http://127.0.0.1:4181/audits` 或目标项目的审计启动流程，也不要求目标项目改成新的任务调度方式。

## 导入到其他项目

在本项目运行 `npm install && npm run build`，然后在接入项目中安装本地目录：

```sh
npm install /Users/wh4lter/Workspace/web-terminal-monitor
```

```tsx
import { TerminalEmbed } from 'web-terminal-monitor';

<TerminalEmbed
  serverUrl="http://127.0.0.1:4183/"
  socket="owa-web-terminal-demo"
  target="opencode-demo:tui"
  readOnly={false}
  height={620}
/>
```

`TerminalEmbed` 加载独立服务的完整终端页面，不需要额外导入 CSS。若需要直接放入宿主布局，使用 `WebTerminal` 并导入 `web-terminal-monitor/styles.css`。无框架前端可用 `buildTerminalEmbedUrl` / `createTerminalClient`；Node 服务可从 `web-terminal-monitor/server` 导入 `createTerminalServer`。

组件属性、跨 origin 配置、Node 生命周期和本地安装包的用法见 [组件接入文档](docs/component.md)。版本 `0.2.0` 的安装包位于 `artifacts/web-terminal-monitor-0.2.0.tgz`，未发布到 npm registry。

## 启动

需要 Node.js 22.12 或更新版本。连接已有 tmux 会话还需要宿主机安装 tmux，并以与任务相同的用户运行此服务。若 node-pty 没有适用的预编译包，安装时需要本机 C/C++ 编译工具；macOS 可安装 Xcode Command Line Tools。

```sh
npm install
npm run build
npm start
```

打开 [终端监控](http://127.0.0.1:4182/)。开发时运行 `npm run dev`，访问 [开发界面](http://127.0.0.1:5182/)；前端为 5182，API / WebSocket 后端为 4182。更改服务配置后重新启动进程。

```sh
npm test
npm run typecheck
```

页面提供固定的演示 TUI 和本机 Shell 启动项。演示在本机运行，不调用 OpenCode 或模型服务。Shell 使用服务进程的用户权限；前端不能提交任意程序路径或启动参数。

安装流程包含 macOS 上 node-pty `spawn-helper` 可执行权限的定向修复。如果使用了 `npm install --ignore-scripts`，首次启动前运行 `node scripts/prepare-pty.mjs`。

## 配置

| 环境变量 | 默认值 | 作用 |
| --- | --- | --- |
| `TERMINAL_HOST` | `127.0.0.1` | 监听地址，只接受回环地址 |
| `TERMINAL_PORT` | `4182` | 服务端口；开发代理默认连接 4182 |
| `PLATFORM_URL` | `http://127.0.0.1:4181/audits` | 返回工作台的链接，并允许该 URL 的 origin 嵌入终端 |
| `TERMINAL_ALLOW_INPUT` | 启用 | 设为 `0` 禁止所有键盘、粘贴和鼠标输入；普通终端默认交互，演示始终只读 |
| `TERMINAL_ALLOW_SHELL` | 启用 | 设为 `0` 隐藏并禁用本机 Shell 启动项 |
| `TERMINAL_CWD` | 当前工作目录 | 本服务创建的终端的工作目录 |
| `TERMINAL_SHELL` | `SHELL`，无则使用平台默认值 | 固定 Shell 可执行文件 |
| `TMUX_BIN` | `tmux` | tmux 可执行文件 |
| `TMUX_SOCKET_NAMES` | `default` | 额外发现的 socket 名，逗号分隔；现有 `owa-*` 始终自动发现 |
| `TERMINAL_ALLOWED_ORIGINS` | 空 | 额外信任的 HTTP / WebSocket origin，逗号分隔；默认同源 |

只用于监控时，可从服务端关闭交互与 Shell：

```sh
TERMINAL_ALLOW_INPUT=0 TERMINAL_ALLOW_SHELL=0 npm start
```

默认 4181 iframe 接入不需要设置 `TERMINAL_ALLOWED_ORIGINS`，因为 iframe 内的 API / WebSocket 仍来自终端服务自身。若更改工作台地址，设置正确的 `PLATFORM_URL` 以匹配嵌入来源；若直接从其他前端调用接口，才需要额外允许其可信 origin。

## 连接已有任务

服务发现当前用户的默认 tmux socket，以及 `/tmp/tmux-<uid>/` 内现有的 `owa-*` socket。`opencode_multi_agents` 为每个任务建立独立的 `owa-<16 位摘要>` socket，内部会话和窗口通常是 `audit:tui`，因此只查询默认 tmux 会话列表会漏掉这些任务。

在会话列表选择任务即可连接。普通终端默认启用交互，也可以切换为只读；服务端禁用输入或内置演示会话始终只读。关闭浏览器、切换任务或断开连接只分离终端客户端，底层 tmux 任务继续运行。终端客户端不主动修改底层 tmux 窗口尺寸，小视口会显示受限区域。

## 键盘、鼠标与粘贴

- 点击终端画面即可输入，Enter、方向键、Tab、Esc 和 Ctrl 组合键由终端发送给后台程序。工具栏的操作帮助中还提供聚焦、Esc、Tab 和 Ctrl+C 按钮，便于处理浏览器拦截的快捷键。
- Ctrl+V / macOS ⌘+V 粘贴；工具栏“粘贴到终端”也可读取剪贴板。若浏览器拒绝读取，会展开手动粘贴框：粘贴后点击“发送到终端”，不额外追加回车。文本本身包含的换行仍会发送；当前程序支持时使用 bracketed paste。
- Ctrl+Shift+C / macOS ⌘+C 复制选中内容。TUI 接管鼠标时，按住 Shift 拖选；macOS 使用 Option 拖选。
- 点击、拖动和滚轮事件按当前 TUI 启用的鼠标模式传递，状态栏会显示“TUI 鼠标已启用”。程序没有启用鼠标协议时，浏览器终端保留文本选择和滚动历史；终端无法替程序增加鼠标功能。
- 中文等输入法交由 xterm.js 的原生 composition 处理，尚未逐一验证所有操作系统和输入法组合。

只读、断线、重连等待和进程退出期间不发送输入。每个会话的模式选择保存在当前标签页的 `sessionStorage`，刷新会保留选择；`readonly=1` 或 `readonly=0` 的 URL 参数优先于保存值。新建 Shell 默认可直接输入，内置 TUI 演示仍然只读。

**现有 OpenCode Runner 输出不会自动变成 TUI。** 当前目标项目在 tmux 中运行 `opencode run --format json`，所以连接后会显示真实的 JSON / 文本事件。若要显示 OpenCode 的交互式 TUI，需要实际存在一个正在运行交互式 OpenCode 的终端。这与终端渲染能力是两个环节。

可手动建立独立会话体验真实 TUI（需已安装并配置 OpenCode）：

```sh
tmux -L wtm-demo new-session -s opencode 'opencode'
```

按 tmux 的 `Ctrl+B`、`D` 分离客户端并保留会话，再从另一终端启动监控服务：

```sh
TMUX_SOCKET_NAMES=default,wtm-demo npm start
```

这会启动独立的 OpenCode 会话，不会替代或接管现有审计任务。服务只能连接它实际发现的会话；URL 参数不能直接指定服务器执行的命令。

## 嵌入 4181 工作台

1. 保持此服务运行在 4182，目标工作台继续运行在 4181。
2. 在原审计数据中取得 `terminal.socket_name`、`terminal.target` 和 `terminal.live`。原工作台的 `GET /api/v1/audits?live=1&tab=all` 可提供 `terminal`（也可能为 `null`）；当前新前端 `/api/workbench/audits` 的归一化结果没有保留该字段，需要在接入方保留这些元数据。
3. 在目标项目安装 `web-terminal-monitor`，将 [React 适配示例](examples/OpencodeTerminalPanel.tsx) 复制到组件目录，在审计详情使用：

```tsx
<OpencodeTerminalPanel terminal={audit.terminal} />
```

该示例从包中导入 `TerminalEmbed`，通过 iframe 加载独立终端，不需要在工作台初始化 xterm.js 或导入终端 CSS。为保留审计监控用途，示例的 `readOnly` 默认是 `true`；需要操作时使用：

```tsx
<OpencodeTerminalPanel terminal={audit.terminal} readOnly={false} />
```

也可以直接嵌入 URL：

```text
http://127.0.0.1:4182/?embed=1&readonly=1&socket=owa-0123456789abcdef&target=audit%3Atui
```

`readonly=1` 表示以只读模式打开，设为 `0` 表示以交互模式打开；服务端始终有最终输入权限。`socket` 匹配发现的 socket；`target` 的会话名部分用于选择会话。页面显示该会话的当前活动窗口，不会通过 URL 切换后台窗口。若已从 `GET /api/sessions` 取得会话 ID，可改用 `session` 参数，例如 `?embed=1&readonly=1&session=tmux%3Aowa-0123456789abcdef%3A%240`。请用 `URLSearchParams` 编码实际值，示例 ID 本身并不存在。

`live: false` 或缺少 socket 时，React 示例显示空态；归档日志仍由原工作台展示。如果页面显示断开，请先确认终端服务、对应 tmux socket 和任务进程仍在运行。

本次本机接入检查（2026-10-03）：4181 服务可达，`GET /audits` 返回 404；上述 `/api/v1/audits` 接口正常返回任务列表，但返回的 5 个任务的 `terminal` 均为 `null`。因此尚未完成 4181 页面嵌入或真实审计终端连通验证；本项目没有调整原平台路由或任务运行流程。

## 数据和运行边界

原平台的文本快照执行过脱敏，本项目直接传输原始 PTY 画面，**不会继承旧接口的脱敏逻辑**。仅用于可信本机环境，不要把终端端口直接暴露到公网。浏览器中的 `127.0.0.1` 指向浏览器所在计算机，因此默认 iframe 方案适用于同一台计算机。

不读取审计日志、私密上下文文件，也不调用审计的启动、暂停、取消接口。tmux 接入保留底层任务的生命周期；本服务创建的演示和 Shell 进程由本服务管理，停止服务时会结束。

多个浏览器连接同一个托管终端时共享屏幕尺寸，以最后一次尺寸请求为准；需要重新适配当前窗口时点击重新连接。外部 tmux 始终跟随来源窗口尺寸。

后端对连接来源、令牌和会话标识进行校验。令牌由 `/api/config` 获取，写请求使用 `X-Terminal-Token`，WebSocket 使用子协议携带；不要把令牌写入链接或日志。这是本机访问约束，不是多用户登录系统。

## 已完成验证

- 41 项核心测试和 3 项包级测试通过，覆盖真实 PTY、独立 tmux、只读权限、鼠标编码、重连、输入流控、跨来源接入、SSR 导入及包文件完整性。
- 历史 socket 回归：70 个失效 socket 不遮蔽活会话，也不产生逐条告警。
- 开发代理的 HTTP 创建及 WebSocket 输出通过实测。
- 浏览器已验证演示 TUI、彩色 Shell 命令、断开重连和嵌入模式；演示数据与真实审计任务分开标示。
- 真实 OpenCode 的浏览器验证：Ctrl+P 打开命令菜单、鼠标点击切换模型菜单、滚轮滚动列表、键盘输入和中文粘贴。
- 独立项目已实际安装 `.tgz` 包，通过严格 NodeNext 类型检查和 Vite 构建；从包导入的后端能启动真实 PTY，原生 React 组件能跨来源连接 OpenCode 并切换只读状态。

## 接口与实现资料

HTTP 与 WebSocket 协议见 [docs/protocol.md](docs/protocol.md)。实现采用 `node-pty → WebSocket → xterm.js`，浏览器完成一批终端数据解析后发送确认，后端据此控制输出速度；重连由后端恢复当前终端画面。

- [xterm.js 流量控制指南](https://xtermjs.org/docs/guides/flowcontrol/)
- [node-pty 官方仓库与安装说明](https://github.com/microsoft/node-pty)
