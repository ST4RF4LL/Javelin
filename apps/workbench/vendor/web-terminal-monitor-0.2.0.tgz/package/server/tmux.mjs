import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { lstat, readdir } from 'node:fs/promises';
import path from 'node:path';
import net from 'node:net';

const execFileAsync = promisify(execFile);
const SOCKET_NAME = /^[A-Za-z0-9_][A-Za-z0-9_.-]{0,100}$/;
const FORMAT = '#{session_id}\t#{session_name}\t#{window_width}\t#{window_height}\t#{session_created}\t#{session_attached}\t#{pane_current_command}\t#{pane_current_path}\t#{status}';
const statusRows = (value) => value === 'off' || value === '0' ? 0 : /^\d+$/.test(value || '') ? Math.min(5, Number(value)) : 1;

async function mapLimited(items, limit, operation) {
  const results = new Array(items.length);
  let next = 0;
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) {
      const index = next++;
      results[index] = await operation(items[index]);
    }
  }));
  return results;
}

function probeSocket(socketPath, timeout = 300) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ path: socketPath });
    let finished = false;
    const finish = (error) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      socket.destroy();
      resolve(error ? { error: error.code || 'UNKNOWN' } : { alive: true });
    };
    const timer = setTimeout(() => finish({ code: 'ETIMEDOUT' }), timeout);
    socket.once('connect', () => finish());
    socket.once('error', finish);
  });
}

export function createTmuxProvider(options = {}) {
  const executable = options.executable || process.env.TMUX_BIN || 'tmux';
  const uid = process.getuid?.();
  const socketDirectory = options.socketDirectory || `/tmp/tmux-${uid}`;
  const names = (options.socketNames ?? process.env.TMUX_SOCKET_NAMES ?? 'default').split(',').map((name) => name.trim()).filter((name) => SOCKET_NAME.test(name));
  const command = options.execFile || execFileAsync;
  const cacheMs = options.cacheMs ?? 3000;
  const maxCandidates = options.maxCandidates ?? 1024;
  let available = new Map();
  let cached;
  let cacheUntil = 0;
  let refreshing;

  async function discoverSockets() {
    const explicit = new Set(names);
    try {
      const directory = await lstat(socketDirectory);
      if (!directory.isDirectory() || directory.isSymbolicLink() || directory.uid !== uid || (directory.mode & 0o022)) return { sockets: [], warnings: ['tmux socket 目录的所有者或权限不可信，已跳过自动发现。'] };
      const entries = await readdir(socketDirectory, { withFileTypes: true });
      const candidates = new Set(names);
      for (const entry of entries) {
        if (!entry.name.startsWith('owa-') || !SOCKET_NAME.test(entry.name) || !entry.isSocket()) continue;
        candidates.add(entry.name);
      }
      const inspected = await mapLimited([...candidates], 8, async (name) => {
        try {
          const stat = await lstat(path.join(socketDirectory, name));
          if (stat.isSocket() && !stat.isSymbolicLink() && stat.uid === uid) return { name, mtime: stat.mtimeMs };
        } catch { /* A named socket is optional. */ }
        return null;
      });
      const valid = inspected.filter(Boolean).sort((a, b) => Number(explicit.has(b.name)) - Number(explicit.has(a.name)) || b.mtime - a.mtime || a.name.localeCompare(b.name));
      const warnings = [];
      if (valid.length > maxCandidates) warnings.push(`发现 ${valid.length} 个 tmux socket，优先检查显式配置及最近更新的 ${maxCandidates} 个。`);
      const selected = valid.slice(0, maxCandidates);
      const probes = await mapLimited(selected, 8, async (entry) => ({ name: entry.name, ...await probeSocket(path.join(socketDirectory, entry.name)) }));
      const errors = probes.filter((probe) => probe.error && !['ECONNREFUSED', 'ENOENT'].includes(probe.error));
      if (errors.length) {
        const denied = errors.filter((probe) => ['EACCES', 'EPERM'].includes(probe.error)).length;
        const timedOut = errors.filter((probe) => probe.error === 'ETIMEDOUT').length;
        warnings.push(`有 ${errors.length} 个 tmux socket 暂时无法访问${denied ? `，其中 ${denied} 个权限不足` : ''}${timedOut ? `，${timedOut} 个响应超时` : ''}。`);
      }
      return { sockets: probes.filter((probe) => probe.alive).map((probe) => probe.name), warnings };
    } catch (error) {
      if (error.code === 'ENOENT') return { sockets: [], warnings: [] };
      throw error;
    }
  }

  async function refreshSessions() {
    let discovered;
    try { discovered = await discoverSockets(); }
    catch {
      available = new Map();
      return { sessions: [], warnings: ['无法读取本机 tmux socket 目录，请检查服务运行用户的权限。'] };
    }
    const { sockets, warnings } = discovered;
    const sessions = [];
    const results = await mapLimited(sockets, 8, async (socket) => {
      try {
        const { stdout } = await command(executable, ['-S', path.join(socketDirectory, socket), 'list-sessions', '-F', FORMAT], { timeout: 3000, maxBuffer: 256 * 1024 });
        const listed = stdout.trim().split('\n').filter(Boolean).map((line) => {
          const [sessionId, sessionName, cols, rows, created, clients, currentCommand, cwd, status] = line.split('\t');
          if (!/^\$\d+$/.test(sessionId)) return null;
          return {
            id: `tmux:${socket}:${sessionId}`, name: sessionName, kind: 'tmux', status: 'running',
            tmuxSocket: socket, sessionName, sessionId,
            command: currentCommand || 'tmux', cwd, cols: Number(cols) || 80, rows: (Number(rows) || 24) + statusRows(status),
            createdAt: new Date(Number(created) * 1000).toISOString(), clients: Number(clients) || 0,
          };
        }).filter(Boolean);
        return { sessions: listed };
      } catch (error) { return { error }; }
    });
    let failed = 0;
    let missingExecutable = false;
    for (const result of results) {
      if (result.sessions) sessions.push(...result.sessions);
      else if (result.error.code === 'ENOENT') missingExecutable = true;
      else if (!/no server running|no sessions|failed to connect|Connection refused|No such file or directory/i.test(result.error.stderr || '')) failed += 1;
    }
    if (missingExecutable) warnings.push('未安装 tmux；仍可使用本服务创建的终端。');
    else if (failed) warnings.push(`有 ${failed} 个运行中的 tmux 服务暂时无法读取会话，请检查权限或稍后重试。`);
    available = new Map(sessions.map((session) => [session.id, session]));
    return { sessions, warnings: [...new Set(warnings)].slice(0, 3) };
  }

  async function listSessions() {
    if (!cached || Date.now() >= cacheUntil) {
      if (!refreshing) {
        refreshing = refreshSessions().then((result) => {
          cached = result;
          cacheUntil = Date.now() + cacheMs;
          return result;
        }).finally(() => { refreshing = undefined; });
      }
      await refreshing;
    }
    return { sessions: cached.sessions.map((session) => ({ ...session })), warnings: [...cached.warnings] };
  }

  async function resolve(id) {
    await listSessions();
    const session = available.get(id);
    return session ? { ...session } : undefined;
  }

  function attach(session, spawnPty, writable) {
    // The identifier must come from discovery, never from a client-supplied shell command.
    if (!available.has(session.id)) throw new Error('tmux 会话已退出');
    const args = ['-S', path.join(socketDirectory, session.tmuxSocket), 'attach-session'];
    if (!writable) args.push('-r');
    args.push('-f', writable ? 'ignore-size' : 'read-only,ignore-size', '-t', session.sessionId);
    return spawnPty(executable, args, {
      name: 'xterm-256color', cols: session.cols, rows: session.rows,
      cwd: process.cwd(), env: { ...process.env, TERM: 'xterm-256color', TMUX: '', TMUX_PANE: '' },
    });
  }

  async function getSize(session) {
    if (!available.has(session.id)) return null;
    const { stdout } = await command(executable, ['-S', path.join(socketDirectory, session.tmuxSocket), 'display-message', '-p', '-t', session.sessionId, '#{window_width}\t#{window_height}\t#{status}'], { timeout: 1500, maxBuffer: 1024 });
    const [rawCols, rawRows, status] = stdout.trim().split('\t');
    const cols = Number(rawCols);
    const rows = Number(rawRows) + statusRows(status);
    return Number.isInteger(cols) && Number.isInteger(rows) && cols > 0 && rows > 0 ? { cols, rows } : null;
  }

  return { listSessions, resolve, attach, getSize };
}
