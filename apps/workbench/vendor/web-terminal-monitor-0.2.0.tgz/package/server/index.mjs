import http from 'node:http';
import crypto from 'node:crypto';
import path from 'node:path';
import { readFile, realpath, stat } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { WebSocketServer, WebSocket } from 'ws';
import { createRuntime } from './runtime.mjs';

export { createRuntime } from './runtime.mjs';
const root = fileURLToPath(new URL('../', import.meta.url));
const MAX_CLIENTS = 16;
const MAX_BODY = 16 * 1024;
const OUTPUT_CHUNK = 16 * 1024;
const OUTPUT_WINDOW = 64 * 1024;
const MAX_OUTPUT_QUEUE = 2 * 1024 * 1024;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.woff2': 'font/woff2' };
const LOCAL_HOSTS = new Set(['127.0.0.1', 'localhost', '[::1]']);
const CORS_METHODS = new Set(['GET', 'POST', 'DELETE', 'OPTIONS']);
const CORS_HEADERS = new Set(['content-type', 'x-terminal-token']);

function configuredOrigins(value, name) {
  const values = typeof value === 'string' ? value.split(',') : value;
  if (!Array.isArray(values)) throw new TypeError(`${name} 必须为来源数组或逗号分隔的字符串`);
  return new Set(values.flatMap((item) => {
    if (typeof item !== 'string') throw new TypeError(`${name} 仅支持精确的 HTTP(S) 来源`);
    const candidate = item.trim();
    if (!candidate) return [];
    let url;
    try { url = new URL(candidate); } catch { /* Reject invalid configuration below. */ }
    if (!url || !['http:', 'https:'].includes(url.protocol) || url.username || url.password ||
        url.pathname !== '/' || url.search || url.hash || candidate.includes('*')) {
      throw new TypeError(`${name} 仅支持精确的 HTTP(S) 来源：${candidate}`);
    }
    return [url.origin];
  }));
}

function safeEqual(actual, expected) {
  if (typeof actual !== 'string') return false;
  const value = Buffer.from(actual);
  const secret = Buffer.from(expected);
  if (value.length !== secret.length) return false;
  return crypto.timingSafeEqual(value, secret);
}

function requestAllowed(req, extraOrigins) {
  let origin;
  try {
    const parsed = new URL(`http://${req.headers.host}`);
    if (!LOCAL_HOSTS.has(parsed.hostname) || parsed.username || parsed.password || parsed.pathname !== '/') return false;
    if (Number(parsed.port || 80) !== req.socket.localPort) return false;
    origin = parsed.origin;
  } catch { return false; }
  if (req.headers.origin && req.headers.origin !== origin && !extraOrigins.has(req.headers.origin)) return false;
  return true;
}

function json(res, status, value) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(value));
}

async function body(req) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY) throw Object.assign(new Error('请求内容过大'), { status: 413 });
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString() || '{}'); }
  catch { throw Object.assign(new Error('无效的 JSON 请求'), { status: 400 }); }
}

function channel(ws) {
  let attachment;
  let closed = false;
  let queue = [];
  let queued = 0;
  let inflight = 0;
  let lastAck = Date.now();
  let alive = true;
  let messageCount = 0;
  let countSince = Date.now();

  function send(message) {
    if (!closed && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(message));
  }
  function flush() {
    while (!closed && queue.length && ws.bufferedAmount < OUTPUT_WINDOW * 2) {
      const message = queue[0];
      if (message.type === 'output' && inflight >= OUTPUT_WINDOW) break;
      queue.shift();
      if (message.type === 'output') {
        queued -= message.data.length;
        if (inflight === 0) lastAck = Date.now();
        inflight += message.data.length;
      }
      send(message);
    }
  }
  function cleanup() {
    if (closed) return;
    closed = true;
    clearInterval(timer);
    queue = [];
    attachment?.detach();
  }
  const viewer = {
    ready(session, readOnly) { send({ type: 'ready', session, readOnly }); },
    output(data) {
      if (closed || !data) return;
      if (queued + inflight + data.length > MAX_OUTPUT_QUEUE) { ws.close(4008, '终端输出积压，请重新连接'); cleanup(); return; }
      for (let start = 0; start < data.length; start += OUTPUT_CHUNK) queue.push({ type: 'output', data: data.slice(start, start + OUTPUT_CHUNK) });
      queued += data.length;
      flush();
    },
    exit(exitCode) { queue.push({ type: 'exit', exitCode: exitCode ?? 0 }); flush(); },
    size(size) {
      // Bound control messages as well when a client stops acknowledging output.
      if (queue.length > 256) { ws.close(4008, '终端输出积压，请重新连接'); cleanup(); return; }
      queue.push({ type: 'resize', ...size }); flush();
    },
    close() { ws.close(1000, '终端已关闭'); cleanup(); },
    isClosed: () => closed || ws.readyState !== WebSocket.OPEN,
  };
  ws.on('message', (raw, binary) => {
    if (closed) return;
    if (Date.now() - countSince > 1000) { messageCount = 0; countSince = Date.now(); }
    if (++messageCount > 500) { ws.close(4008, '请求过于频繁'); return; }
    if (binary) { ws.close(1003, '仅支持 JSON 消息'); return; }
    let message;
    try { message = JSON.parse(raw.toString()); }
    catch { ws.close(1003, '无效的 JSON 消息'); return; }
    if (!message || typeof message !== 'object') return;
    if (message.type === 'ack') {
      if (!Number.isSafeInteger(message.chars) || message.chars <= 0 || message.chars > inflight) { ws.close(1008, '无效的输出确认'); return; }
      inflight -= message.chars;
      lastAck = Date.now();
      flush();
    } else if (message.type === 'input') {
      const encoding = message.encoding === undefined ? 'utf8' : message.encoding;
      if (typeof message.data !== 'string' || message.data.length > 8192 ||
          !['utf8', 'binary'].includes(encoding) ||
          (encoding === 'binary' && /[^\x00-\xff]/.test(message.data))) {
        send({ type: 'error', message: '无效的终端输入或编码' });
        return;
      }
      // xterm's onBinary emits a byte string (not Unicode), including legacy
      // mouse coordinates above 0x7f. A Buffer prevents node-pty UTF-8 expansion.
      attachment?.input(encoding === 'binary' ? Buffer.from(message.data, 'latin1') : message.data);
    } else if (message.type === 'resize' && Number.isSafeInteger(message.cols) && Number.isSafeInteger(message.rows)) {
      attachment?.resize(message.cols, message.rows);
    }
  });
  ws.on('pong', () => { alive = true; });
  ws.on('close', cleanup);
  ws.on('error', cleanup);
  const timer = setInterval(() => {
    if (!alive || (inflight >= OUTPUT_WINDOW && Date.now() - lastAck > 30_000)) { ws.terminate(); cleanup(); return; }
    alive = false;
    if (ws.readyState === WebSocket.OPEN) ws.ping();
    flush();
  }, 10_000);
  timer.unref();
  return {
    viewer,
    setAttachment(value) { attachment = value; if (closed) attachment?.detach(); },
    fail(error) { send({ type: 'error', message: error.message || '连接终端失败' }); ws.close(1011, '连接终端失败'); cleanup(); },
  };
}

export function createServer(options = {}) {
  const runtime = options.runtime || createRuntime(options);
  const dist = path.resolve(options.dist || path.join(root, 'dist'));
  const extraOrigins = configuredOrigins(options.allowedOrigins ?? options.trustedOrigins ?? process.env.TERMINAL_ALLOWED_ORIGINS ?? '', 'allowedOrigins');
  let platformOrigin;
  try { platformOrigin = new URL(runtime.config().platformUrl).origin; }
  catch { throw new Error('PLATFORM_URL 必须是有效 URL'); }
  const frameOrigins = configuredOrigins(options.frameOrigins ?? process.env.TERMINAL_FRAME_ORIGINS ?? platformOrigin, 'frameOrigins');

  const server = http.createServer(async (req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Content-Security-Policy', `default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'self'${[...frameOrigins].map((origin) => ` ${origin}`).join('')}; base-uri 'none'; object-src 'none'`);
    res.setHeader('Vary', 'Origin');
    if (!requestAllowed(req, extraOrigins)) return json(res, 403, { error: '此终端仅允许本机受信来源访问' });
    if (extraOrigins.has(req.headers.origin)) {
      res.setHeader('Access-Control-Allow-Origin', req.headers.origin);
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Terminal-Token');
    }
    if (req.method === 'OPTIONS') {
      const method = req.headers['access-control-request-method'];
      const headers = String(req.headers['access-control-request-headers'] || '').split(',').map((value) => value.trim().toLowerCase()).filter(Boolean);
      if ((method && !CORS_METHODS.has(method)) || headers.some((header) => !CORS_HEADERS.has(header))) {
        return json(res, 403, { error: '不支持此跨来源请求方法或请求头' });
      }
      res.writeHead(204); res.end(); return;
    }
    try {
      const url = new URL(req.url, `http://${req.headers.host}`);
      if (url.pathname.startsWith('/api/')) {
        if (!['GET', 'HEAD'].includes(req.method) && !safeEqual(req.headers['x-terminal-token'], runtime.token)) return json(res, 403, { error: '终端授权已失效，请刷新页面' });
        if (url.pathname === '/api/config' && req.method === 'GET') return json(res, 200, runtime.config());
        if (url.pathname === '/api/sessions' && req.method === 'GET') return json(res, 200, await runtime.listSessions());
        if (url.pathname === '/api/sessions' && req.method === 'POST') return json(res, 201, { session: runtime.createSession(await body(req)) });
        const match = url.pathname.match(/^\/api\/sessions\/([^/]+)$/);
        if (match) {
          const id = decodeURIComponent(match[1]);
          if (req.method === 'GET') {
            const session = await runtime.getSession(id);
            return json(res, session ? 200 : 404, session ? { session } : { error: '终端会话不存在或已退出' });
          }
          if (req.method === 'DELETE') { await runtime.removeSession(id); return json(res, 200, { ok: true }); }
        }
        return json(res, 404, { error: '接口不存在' });
      }
      if (!['GET', 'HEAD'].includes(req.method)) return json(res, 405, { error: '不支持此请求方法' });
      let filename = path.resolve(dist, '.' + decodeURIComponent(url.pathname));
      if (filename !== dist && !filename.startsWith(dist + path.sep)) return json(res, 403, { error: '路径不可访问' });
      try {
        if (!(await stat(filename)).isFile()) throw new Error('not a file');
      } catch {
        if (path.extname(url.pathname)) return json(res, 404, { error: '文件不存在' });
        filename = path.join(dist, 'index.html');
      }
      const resolved = await realpath(filename);
      const resolvedDist = await realpath(dist);
      if (!resolved.startsWith(resolvedDist + path.sep)) return json(res, 403, { error: '路径不可访问' });
      const content = await readFile(resolved);
      res.writeHead(200, { 'Content-Type': MIME[path.extname(resolved)] || 'application/octet-stream', 'Cache-Control': path.basename(resolved) === 'index.html' ? 'no-cache' : 'public, max-age=3600' });
      res.end(req.method === 'HEAD' ? undefined : content);
    } catch (error) {
      if (res.headersSent) { res.end(); return; }
      const status = error.status || (error.code === 'ENOENT' ? 503 : error instanceof URIError ? 400 : 500);
      json(res, status, { error: error.code === 'ENOENT' ? '前端尚未构建，请先运行 npm run build' : error.message || '服务暂时不可用' });
    }
  });
  server.headersTimeout = 10_000;
  server.requestTimeout = 15_000;
  const wss = new WebSocketServer({ noServer: true, maxPayload: MAX_BODY, perMessageDeflate: false, handleProtocols: () => 'terminal-v1' });
  server.on('upgrade', (req, socket, head) => {
    const reject = (status = 403) => { socket.end(`HTTP/1.1 ${status} Rejected\r\nConnection: close\r\n\r\n`); };
    if (!requestAllowed(req, extraOrigins)) { reject(); return; }
    let url;
    try { url = new URL(req.url, `http://${req.headers.host}`); }
    catch { reject(400); return; }
    const match = url.pathname.match(/^\/api\/terminal\/([^/]+)$/);
    const protocols = String(req.headers['sec-websocket-protocol'] || '').split(',').map((value) => value.trim());
    if (!match || !protocols.includes('terminal-v1') || !protocols.some((value) => safeEqual(value, runtime.token))) { reject(); return; }
    if (wss.clients.size >= (options.maxClients || MAX_CLIENTS)) { reject(429); return; }
    let id;
    try { id = decodeURIComponent(match[1]); }
    catch { reject(400); return; }
    wss.handleUpgrade(req, socket, head, async (ws) => {
      const connection = channel(ws);
      try { connection.setAttachment(await runtime.attach(id, connection.viewer, url.searchParams.get('input') === '1')); }
      catch (error) { connection.fail(error); }
    });
  });
  let closing;
  async function close() {
    if (closing) return closing;
    closing = (async () => {
      for (const ws of wss.clients) ws.terminate();
      await runtime.close();
      await new Promise((resolve) => wss.close(resolve));
      if (server.listening) await new Promise((resolve) => server.close(resolve));
    })();
    return closing;
  }
  return { server, runtime, close };
}

// Importing this module never binds a port; the application owns listen/close.
export const createTerminalServer = createServer;

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const host = process.env.TERMINAL_HOST || '127.0.0.1';
  const port = Number(process.env.TERMINAL_PORT || 4182);
  if (!['127.0.0.1', 'localhost', '::1'].includes(host)) throw new Error('TERMINAL_HOST 必须是回环地址；远程访问请使用安全隧道');
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('TERMINAL_PORT 无效');
  const app = createServer();
  app.server.on('error', (error) => { console.error(`终端服务启动失败：${error.message}`); process.exitCode = 1; app.close(); });
  app.server.listen(port, host, () => console.log(`Web Terminal Monitor → http://${host === '::1' ? '[::1]' : host}:${port}`));
  let exiting = false;
  const shutdown = async () => { if (exiting) return; exiting = true; await app.close(); };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}
