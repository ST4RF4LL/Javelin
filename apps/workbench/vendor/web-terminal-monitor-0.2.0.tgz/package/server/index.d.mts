import type { Server } from 'node:http';
import type { IPty, IPtyForkOptions } from 'node-pty';

export interface TerminalSize {
  cols: number;
  rows: number;
}

export interface TerminalSession extends TerminalSize {
  id: string;
  name: string;
  kind: 'managed' | 'tmux';
  status: 'running' | 'exited';
  command?: string;
  cwd?: string;
  createdAt?: string;
  clients?: number;
  exitCode?: number;
  profile?: string;
  tmuxSocket?: string;
  sessionName?: string;
  sessionId?: string;
}

export interface TmuxSession extends TerminalSession {
  kind: 'tmux';
  tmuxSocket: string;
  sessionName: string;
  sessionId: string;
}

export interface SessionList {
  sessions: TerminalSession[];
  warnings: string[];
}

export interface TerminalConfig {
  platformUrl: string;
  allowInput: boolean;
  profiles: { id: string; label: string; description: string }[];
  version: string;
  token: string;
}

export interface CreateSessionOptions {
  profile: 'demo' | 'shell';
  cols?: number;
  rows?: number;
}

export interface TerminalViewer {
  ready(session: TerminalSession, readOnly: boolean): void;
  output(data: string): void;
  exit(exitCode?: number): void;
  size?(size: TerminalSize & { fixed?: boolean }): void;
  close(): void;
  isClosed(): boolean;
}

export interface TerminalAttachment {
  input(data: string | Buffer): void;
  resize(cols: number, rows: number): void;
  /** Detaches this viewer; an existing tmux session continues running. */
  detach(): void;
}

export type TerminalPty = Pick<IPty, 'onData' | 'onExit' | 'write' | 'resize' | 'kill'> &
  Partial<Pick<IPty, 'pause' | 'resume'>>;
export type SpawnTerminalPty = (executable: string, args: string[], options: IPtyForkOptions) => TerminalPty;

export interface TmuxProvider {
  listSessions(): Promise<{ sessions: TmuxSession[]; warnings: string[] }>;
  resolve(id: string): Promise<TmuxSession | undefined>;
  attach(session: TmuxSession, spawnPty: SpawnTerminalPty, writable: boolean): TerminalPty;
  getSize?(session: TmuxSession): Promise<TerminalSize | null>;
}

export interface TerminalRuntimeOptions {
  /** Defaults to TERMINAL_ALLOW_INPUT !== '0'. Each connection must also request input. */
  allowInput?: boolean;
  /** Whether clients can create a shell profile. Defaults to TERMINAL_ALLOW_SHELL !== '0'. */
  allowShell?: boolean;
  cwd?: string;
  shell?: string;
  maxSessions?: number;
  platformUrl?: string;
  /** Override the PTY implementation, for example when integrating with a process manager. */
  spawnPty?: SpawnTerminalPty;
  tmux?: TmuxProvider;
  onError?: (error: unknown) => void;
}

export interface TerminalRuntime {
  readonly token: string;
  readonly allowInput: boolean;
  config(): TerminalConfig;
  createSession(options: CreateSessionOptions): TerminalSession;
  listSessions(): Promise<SessionList>;
  getSession(id: string): Promise<TerminalSession | undefined>;
  removeSession(id: string): Promise<void>;
  attach(id: string, viewer: TerminalViewer, requestedInput?: boolean): Promise<TerminalAttachment | null>;
  /** Stops managed processes and detaches tmux viewers without terminating their source sessions. */
  close(): Promise<void>;
}

/** Exact HTTP(S) origins, as an array or a comma-separated string. Wildcards are rejected. */
export type TerminalOrigins = string | readonly string[];

export interface TerminalServerOptions extends TerminalRuntimeOptions {
  /** Existing runtime. When supplied, runtime creation options above are ignored. */
  runtime?: TerminalRuntime;
  /** Directory containing the standalone web app. Defaults to the package's dist directory. */
  dist?: string;
  maxClients?: number;
  /** Trusted browser origins for HTTP CORS and WebSocket upgrades. Defaults to TERMINAL_ALLOWED_ORIGINS. */
  allowedOrigins?: TerminalOrigins;
  /** Compatibility alias used only when allowedOrigins is absent. */
  trustedOrigins?: TerminalOrigins;
  /**
   * Extra iframe ancestors in addition to 'self'; this does not grant API or WebSocket access.
   * Defaults to TERMINAL_FRAME_ORIGINS or platformUrl's origin. An empty array permits only 'self'.
   */
  frameOrigins?: TerminalOrigins;
}

export interface TerminalServer {
  /** Unbound Node HTTP server. Call server.listen(port, '127.0.0.1') explicitly. */
  server: Server;
  runtime: TerminalRuntime;
  /** Closes HTTP/WebSocket connections and the runtime, including a supplied runtime. Idempotent. */
  close(): Promise<void>;
}

export function createRuntime(options?: TerminalRuntimeOptions): TerminalRuntime;
export function createServer(options?: TerminalServerOptions): TerminalServer;
/** Preferred package entry point. Creating or importing it never starts a listener. */
export const createTerminalServer: typeof createServer;
